const { onValueWritten } = require("firebase-functions/v2/database");
const { setGlobalOptions } = require("firebase-functions/v2/options");
const admin = require("firebase-admin");

admin.initializeApp();
setGlobalOptions({ region: "asia-southeast2", maxInstances: 5 });

const db = admin.database();
const messaging = admin.messaging();

function orderLabel(order) {
  return order?.title || "Order baru";
}

function eligibleDriver(d, order) {
  if (!d || d.online !== true || d.ready !== true || d.busy === true) return false;
  const type = order?.orderType || "";
  if (type === "female" && d.gender !== "female") return false;
  if (type === "male" && d.gender !== "male") return false;
  return true;
}

async function getDriverTokens(order) {
  const snap = await db.ref("go_v2/drivers").once("value");
  const drivers = snap.val() || {};
  const result = [];
  for (const [id, d] of Object.entries(drivers)) {
    if (eligibleDriver(d, order) && d.fcmToken) {
      result.push({ id, token: d.fcmToken });
    }
  }
  return result;
}

async function getAdminTokens() {
  const snap = await db.ref("go_v2/adminTokens").once("value");
  const data = snap.val() || {};
  return Object.entries(data)
    .map(([id, x]) => ({ id, token: x?.token }))
    .filter(x => !!x.token);
}

async function send(tokens, title, body, tag) {
  const clean = [...new Set(tokens.filter(Boolean))];
  if (!clean.length) return;

  for (let i = 0; i < clean.length; i += 500) {
    const chunk = clean.slice(i, i + 500);
    const response = await messaging.sendEachForMulticast({
      tokens: chunk,
      notification: { title, body },
      data: {
        title,
        body,
        tag: tag || "grup-order",
        url: "/"
      },
      webpush: {
        notification: {
          title,
          body,
          requireInteraction: false,
          silent: false,
          renotify: true
        }
      }
    });
    console.log("Push sent:", response.successCount, "failed:", response.failureCount);
  }
}

exports.orderNotifications = onValueWritten(
  "/go_v2/orders/{orderId}",
  async (event) => {
    const before = event.data.before.val();
    const after = event.data.after.val();
    if (!after) return;

    const orderName = orderLabel(after);

    // 1) Order baru -> semua driver yang sedang READY dan memenuhi request.
    const isNew = !before && after.status === "open";
    if (isNew) {
      const recipients = await getDriverTokens(after);
      await send(
        recipients.map(x => x.token),
        "📣 ADA ORDERAN BARU",
        `${orderName} — silakan cek GRUP ORDER.`,
        `new-${event.params.orderId}`
      );
      return;
    }

    const oldIds = Object.keys(before?.driverIds || {});
    const newIds = Object.keys(after.driverIds || {});
    const added = newIds.filter(id => !oldIds.includes(id));

    // 2) Driver mengambil order -> admin diberi nama driver.
    if (added.length) {
      const admins = await getAdminTokens();
      for (const did of added) {
        const name = after.driverNames?.[did] || "Driver";
        await send(
          admins.map(x => x.token),
          "🔔 ORDER DIAMBIL DRIVER",
          `${name} mengambil ${orderName}.`,
          `claim-${event.params.orderId}-${did}`
        );
      }
    }

    // 3) Order selesai -> semua driver terkait + admin.
    if (before?.status !== "completed" && after.status === "completed") {
      const driverSnap = await db.ref("go_v2/drivers").once("value");
      const drivers = driverSnap.val() || {};
      const recipients = [];
      for (const did of newIds) {
        if (drivers[did]?.fcmToken) recipients.push(drivers[did].fcmToken);
      }
      const admins = await getAdminTokens();
      await send(
        recipients.concat(admins.map(x => x.token)),
        "✅ ORDERAN SELESAI",
        `${orderName} sudah selesai.`,
        `done-${event.params.orderId}`
      );
    }
  }
);
