GRUP ORDER — BUILD DARI HP

1. Install AndroidIDE dari sumber resmi GitHub/F-Droid. AndroidIDE mendukung project Gradle di perangkat Android, tetapi proyek AndroidIDE sendiri sudah tidak dipelihara lagi; gunakan hanya sumber resminya.
2. Buka AndroidIDE dan izinkan akses file yang diminta.
3. Ekstrak ZIP ini ke penyimpanan internal, misalnya /Download/GRUP_ORDER_ANDROID.
4. Di AndroidIDE pilih Open/Import Project dan pilih folder GRUP_ORDER_ANDROID (folder yang berisi settings.gradle).
5. Jika AndroidIDE meminta JDK, pilih JDK 17.
6. Tunggu Gradle mengunduh dependency. Wi-Fi disarankan karena Firebase/AndroidX cukup besar.
7. Pilih build variant debug lalu Build/Quick Run.
8. APK biasanya muncul di app/build/outputs/apk/debug/app-debug.apk.

PENTING
- Jangan menghapus google-services.json.
- Jangan mengubah applicationId/package: com.olumajang.gruporder
- Android 13+ harus diberi izin notifikasi saat aplikasi pertama kali dibuka.
- Untuk HP TECNO, setelah APK terpasang, izinkan notifikasi dan matikan pembatasan baterai untuk GRUP ORDER agar pengantaran notifikasi lebih andal.
