import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import {
  getAuth,
  signInAnonymously,
  onAuthStateChanged,
  signOut
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import {
  getDatabase,
  ref,
  onValue,
  set,
  update,
  remove,
  runTransaction,
  onDisconnect,
  push
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-database.js";
import {
  getMessaging,
  getToken,
  onMessage,
  isSupported as messagingSupported
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-messaging.js";

const firebaseConfig = {
  apiKey: "AIzaSyCumTDIAItVvb0aiiNP4cGLSCQp8Lctbrw",
  authDomain: "grup-order.firebaseapp.com",
  databaseURL: "https://grup-order-default-rtdb.firebaseio.com",
  projectId: "grup-order",
  storageBucket: "grup-order.firebasestorage.app",
  messagingSenderId: "829149207302",
  appId: "1:829149207302:web:7f21f7aadd3f17a98f5c87",
  measurementId: "G-BXMNC23565"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);
let messaging = null;
let messagingRegistration = null;
const PUSH_VAPID_KEY = ""; // Firebase Web Push default key akan digunakan bila kosong.

// Android APK: native FCM token dikirim dari MainActivity.
window.__nativeFcmToken = window.__nativeFcmToken || "";
window.setNativeFcmToken = function(token) {
  if (!token) return;
  window.__nativeFcmToken = token;
  try {
    window.dispatchEvent(new CustomEvent("nativeFcmTokenReady"));
  } catch {}
};

function waitForNativeFcmToken(timeoutMs = 12000) {
  if (window.__nativeFcmToken) return Promise.resolve(window.__nativeFcmToken);
  return new Promise((resolve) => {
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      window.removeEventListener("nativeFcmTokenReady", finish);
      resolve(window.__nativeFcmToken || "");
    };
    window.addEventListener("nativeFcmTokenReady", finish, { once: true });
    setTimeout(finish, timeoutMs);
  });
}

async function saveNativeFcmToken() {
  const token = window.__nativeFcmToken;
  if (!token || !uid) return false;
  if (role === "admin") {
    await set(ref(db, `${ROOT}/adminTokens/${uid}`), { token, updatedAt: Date.now() });
  } else if (role === "driver") {
    await update(ref(db, `${ROOT}/drivers/${uid}`), {
      fcmToken: token,
      pushEnabled: true,
      updatedAt: Date.now()
    });
  }
  localStorage.setItem("go_fcm_token", token);
  return true;
}

const ADMIN_CODE_HASH =
  "6891cb93b69e35561f38794f88a8745f60f9d287a87621c3ccc935284b8c49aa";

const ROOT = "go_v2";
const BUSY_MS = 5 * 60 * 1000;

let uid = null;
let role = null;
let myName = null;
let listeners = [];
let lastOpenIds = new Set();
let selectedMode = "one";
let selectedOrderType = "makanan";
let lastOrders = {};
let adminOrderSnapshotReady = false;
let adminClaimState = {};
let adminPreviousOrders = {};
let driverChatBound = false;
let soundEnabled = localStorage.getItem("go_sound") !== "off";

const $ = (id) => document.getElementById(id);

const show = (id, on) => {
  const el = $(id);
  if (el) el.classList.toggle("hidden", !on);
};

const toast = (msg) => {
  const el = $("toast");
  if (!el) return;
  el.textContent = msg;
  el.classList.remove("hidden");
  setTimeout(() => el.classList.add("hidden"), 2600);
};

let audioCtx = null;
let audioUnlocked = false;

function unlockAudio() {
  try {
    const C = window.AudioContext || window.webkitAudioContext;
    if (!C) return;
    if (!audioCtx) audioCtx = new C();
    if (audioCtx.state === "suspended") audioCtx.resume();
    audioUnlocked = true;
  } catch {}
}

function fallbackBeep(count = 2) {
  try {
    unlockAudio();
    if (!audioCtx) return;
    for (let i = 0; i < count; i++) {
      const t = i * 0.42;
      const o = audioCtx.createOscillator();
      const g = audioCtx.createGain();
      o.type = "sine";
      o.frequency.value = i % 2 ? 1120 : 860;
      g.gain.setValueAtTime(0.0001, audioCtx.currentTime + t);
      g.gain.exponentialRampToValueAtTime(0.38, audioCtx.currentTime + t + 0.03);
      g.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + t + 0.28);
      o.connect(g); g.connect(audioCtx.destination);
      o.start(audioCtx.currentTime + t);
      o.stop(audioCtx.currentTime + t + 0.32);
    }
  } catch {}
}

function vibrateAlert(type = "new") {
  if (!navigator.vibrate) return;
  try {
    const patterns = {
      new: [260],                   // 1 getaran
      received: [260],              // 1 getaran
      done: [260]                   // 1 getaran
    };
    navigator.vibrate(patterns[type] || patterns.received);
  } catch {}
}

let preferredGoogleVoice = null;

function chooseGoogleFemaleVoice() {
  const synth = window.speechSynthesis;
  if (!synth) return null;
  const voices = synth.getVoices ? synth.getVoices() : [];
  if (!voices.length) return preferredGoogleVoice;
  const idVoices = voices.filter(v => /^id(-|_)?ID$/i.test(v.lang || "") || /indones/i.test(v.lang || ""));
  const pool = idVoices.length ? idVoices : voices;
  // Android/Chrome biasanya menyediakan Google Bahasa Indonesia.
  // Jika metadata gender tidak tersedia, nama voice Google tetap diprioritaskan.
  preferredGoogleVoice =
    pool.find(v => /google/i.test(v.name || "") && /female|woman|perempuan/i.test(v.name || "")) ||
    pool.find(v => /google/i.test(v.name || "")) ||
    pool.find(v => /female|woman|perempuan/i.test(v.name || "")) ||
    pool.find(v => /^id/i.test(v.lang || "")) ||
    pool[0] || null;
  return preferredGoogleVoice;
}

if (window.speechSynthesis) {
  chooseGoogleFemaleVoice();
  window.speechSynthesis.onvoiceschanged = chooseGoogleFemaleVoice;
}

function speakSequence(text, count = 2, type = "received") {
  if (!soundEnabled) return;
  unlockAudio();
  vibrateAlert(type);

  const synth = window.speechSynthesis;
  if (!synth) {
    fallbackBeep(count);
    return;
  }

  try {
    synth.cancel();
    const voice = chooseGoogleFemaleVoice();
    let i = 0;
    const next = () => {
      if (!soundEnabled || i >= count) return;
      const u = new SpeechSynthesisUtterance(text);
      u.lang = voice?.lang || "id-ID";
      if (voice) u.voice = voice;
      // Google Indonesian voice dibuat natural, bukan suara robot bernada tinggi.
      u.rate = type === "new" ? 1.02 : 1.00;
      u.pitch = type === "new" ? 1.08 : type === "done" ? 1.04 : 1.02;
      u.volume = 1;
      u.onend = () => setTimeout(next, type === "new" ? 220 : 260);
      u.onerror = () => { if (i === 0) fallbackBeep(count); };
      i++;
      synth.speak(u);
    };
    next();
  } catch {
    fallbackBeep(count);
  }
}

function announceNewOrder(extra = "") {
  speakSequence(extra ? `Ada orderan, ${extra}` : "Ada orderan", 1, "new");
}
function announceOrderReceived(driverName = "") {
  speakSequence(driverName ? `${driverName} yang ambil order` : "Order baru diterima", 1, "received");
}
function announceOrderFinished() {
  speakSequence("Orderan selesai", 1, "done");
}

function ringOrder() {
  announceNewOrder();
}

document.addEventListener("pointerdown", unlockAudio, { once: true });
document.addEventListener("touchstart", unlockAudio, { once: true });

const norm = (s) =>
  String(s || "").trim().toLowerCase().replace(/\s+/g, " ");

const esc = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (m) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  }[m]));

const ICON = {
  scooter: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 17h10.5a3.5 3.5 0 0 0 0-7H14l-2-4H8"/><circle cx="7" cy="17" r="3"/><circle cx="18" cy="17" r="3"/><path d="M10 10h5"/></svg>',
  food: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 3v7M10 3v7M13 3v7M10 10v11"/><path d="M7 3v18M16 3v18M16 3c2 0 3 1 3 3v3c0 2-1 3-3 3"/></svg>',
  shop: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 8h14l-1 12H6L5 8Z"/><path d="M8 8V6a4 4 0 0 1 8 0v2"/></svg>',
  ride: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="6" cy="17" r="3"/><circle cx="18" cy="17" r="3"/><path d="M6 17h5l2-7h3l2 7M11 17l-3-6h4"/></svg>',
  send: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m4 4 16 8-16 8 3-8-3-8Z"/><path d="M7 12h13"/></svg>',
  female: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M12 12v9M8 17h8"/></svg>',
  male: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10" cy="14" r="4"/><path d="m13 11 6-6M15 5h4v4"/></svg>',
  users: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="9" cy="8" r="3"/><path d="M3 20v-1a6 6 0 0 1 12 0v1M16 11a3 3 0 0 1 5 3v1M17 5a3 3 0 0 1 3 3"/></svg>',
  camera: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h4l2-2h4l2 2h4v12H4V7Z"/><circle cx="12" cy="13" r="3.5"/></svg>',
  speaker: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 10v4h4l5 4V6l-5 4H4Z"/><path d="M17 9a5 5 0 0 1 0 6M19 6a9 9 0 0 1 0 12"/></svg>',
  bell: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18 9a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/></svg>',
  check: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12 4 4L19 6"/></svg>',
  close: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18"/></svg>',
  logout: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10 17l5-5-5-5M15 12H3M21 3v18"/></svg>',
  message: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h16v12H8l-4 4V5Z"/></svg>'
};

const ORDER_TYPES = {
  makanan: { label: "O-MAKANAN", icon: ICON.food },
  toko: { label: "O-TOKO", icon: ICON.shop },
  naik: { label: "O-NAIK", icon: ICON.ride },
  kirim: { label: "O-KIRIM", icon: ICON.send },
  female: { label: "PERMINTAAN CEWEK", icon: ICON.female },
  male: { label: "PERMINTAAN COWOK", icon: ICON.male },
  all: { label: "SEMUA PESANAN", icon: ICON.users }
};

function orderTypeInfo(type) {
  const aliases = { food: "makanan", shop: "toko", ride: "naik", send: "kirim" };
  return ORDER_TYPES[aliases[type] || type] || ORDER_TYPES.makanan;
}

function orderAllowedForDriver(o) {
  const type = o?.orderType || (o?.requestFemale ? "female" : o?.requestMale ? "male" : "makanan");
  const gender = window.__myDriverGender || "";
  if (type === "female") return gender === "female";
  if (type === "male") return gender === "male";
  return true;
}

async function ensureAuth() {
  if (!auth.currentUser) {
    await signInAnonymously(auth);
  }
}

async function restoreSession() {
  if (!uid) return;

  const raw = localStorage.getItem("go_session");
  if (!raw) return;

  try {
    const session = JSON.parse(raw);

    if (session.role === "driver") {
      const snap = await new Promise((resolve) =>
        onValue(ref(db, `${ROOT}/drivers/${uid}`), resolve, { onlyOnce: true })
      );

      const d = snap.val();
      if (!d?.name) {
        localStorage.removeItem("go_session");
        return;
      }

      myName = d.name;
      role = "driver";

      const shouldBeOnline = d.manualOff !== true;

      await update(ref(db, `${ROOT}/drivers/${uid}`), {
        online: shouldBeOnline,
        updatedAt: Date.now()
      });

      onDisconnect(ref(db, `${ROOT}/drivers/${uid}`)).update({
        online: false,
        updatedAt: Date.now()
      });

      const nr = ref(
        db,
        `${ROOT}/nameIndex/${encodeURIComponent(norm(d.name))}`
      );

      const tx = await runTransaction(
        nr,
        (current) => (current === null || current === uid ? uid : current)
      );

      // nameIndex tetap dipertahankan agar nama tidak bisa dipakai login dobel.
      if ($("driverName")) $("driverName").textContent = d.name;
      if ($("driverNameHero")) $("driverNameHero").textContent = d.name;
      if ($("driverGender")) $("driverGender").value = d.gender || "";

      show("loginCard", false);
      show("driverPanel", true);
      show("adminPanel", false);

      await setupBackgroundNotifications();
      bindDriver();
      return;
    }

    if (session.role === "admin") {
      role = "admin";
      show("loginCard", false);
      show("driverPanel", false);
      show("adminPanel", true);
      await setupAdminBackgroundNotifications();
      bindAdmin();
    }
  } catch (e) {
    console.warn("Pemulihan sesi gagal:", e);
  }
}

onAuthStateChanged(auth, async (u) => {
  uid = u?.uid || null;
  $("onlineBadge")?.classList.toggle("off", !u);

  if (u) {
    await restoreSession();
  }
});

async function reserveName(name, gender, pin) {
  const key = norm(name);

  if (!key || key.length < 2) {
    throw new Error("Nama minimal 2 karakter.");
  }
  if (pin !== "1234") {
    throw new Error("PIN peserta salah. Gunakan PIN 1234.");
  }

  const r = ref(db, `${ROOT}/nameIndex/${encodeURIComponent(key)}`);

  // Jika perangkat yang sama mengganti nama, lepaskan index nama lama.
  const existingSnap = await new Promise((resolve) =>
    onValue(ref(db, `${ROOT}/drivers/${uid}`), resolve, { onlyOnce: true })
  );
  const existing = existingSnap.val() || {};
  if (existing.name && norm(existing.name) !== key) {
    await remove(ref(db, `${ROOT}/nameIndex/${encodeURIComponent(norm(existing.name))}`));
  }

  // Nama menjadi identitas unik peserta. Index TIDAK dihapus ketika offline,
  // sehingga dua perangkat tidak dapat login dengan nama yang sama.
  let tx = await runTransaction(r, (current) => {
    if (current === null) return uid;
    return current === uid ? uid : current;
  });

  if (!tx.committed || tx.snapshot.val() !== uid) {
    throw new Error("Nama sudah terdaftar. Gunakan nama peserta yang berbeda atau minta Admin menghapus akun dobel.");
  }

  await set(ref(db, `${ROOT}/drivers/${uid}`), {
    uid,
    name: name.trim(),
    gender: gender || "",
    pinRequired: true,
    ready: true,
    busy: false,
    busyUntil: 0,
    online: true,
    manualOff: false,
    requestFemale: false,
    updatedAt: Date.now()
  });

  onDisconnect(ref(db, `${ROOT}/drivers/${uid}`)).update({
    online: false,
    updatedAt: Date.now()
  });

  // Jangan onDisconnect(r).remove(): nama tetap terkunci walau peserta offline.
  return key;
}

async function setupBackgroundNotifications() {
  // APK Android: FCM ditangani native agar tetap bekerja saat layar terkunci.
  if (window.AndroidFCM) {
    await waitForNativeFcmToken();
    try { await saveNativeFcmToken(); } catch (e) { console.warn("Gagal menyimpan token native:", e); }
    return;
  }
  if (!("serviceWorker" in navigator) || !("Notification" in window)) return;
  try {
    if (Notification.permission === "default") {
      await Notification.requestPermission();
    }
    if (Notification.permission !== "granted") return;

    const supported = await messagingSupported();
    if (!supported) return;

    messagingRegistration = await navigator.serviceWorker.register("./firebase-messaging-sw.js");
    messaging = getMessaging(app);

    const tokenOptions = { serviceWorkerRegistration: messagingRegistration };
    if (PUSH_VAPID_KEY) tokenOptions.vapidKey = PUSH_VAPID_KEY;

    const token = await getToken(messaging, tokenOptions);
    if (token && uid) {
      await update(ref(db, `${ROOT}/drivers/${uid}`), {
        fcmToken: token,
        pushEnabled: true,
        updatedAt: Date.now()
      });
      localStorage.setItem("go_fcm_token", token);
    }

    onMessage(messaging, (payload) => {
      const title = payload?.notification?.title || payload?.data?.title || "GRUP ORDER";
      const body = payload?.notification?.body || payload?.data?.body || "Ada pembaruan order.";
      toast(body);
      if (soundEnabled) {
        try { ringOrder(); } catch {}
        try { vibrateAlert("new"); } catch {}
      }
    });
  } catch (e) {
    console.warn("Notifikasi latar belakang belum aktif:", e);
  }
}

async function setupAdminBackgroundNotifications() {
  // APK Android: FCM ditangani native agar tetap bekerja saat layar terkunci.
  if (window.AndroidFCM) {
    await waitForNativeFcmToken();
    try { await saveNativeFcmToken(); } catch (e) { console.warn("Gagal menyimpan token native admin:", e); }
    return;
  }
  if (!("serviceWorker" in navigator) || !("Notification" in window)) return;
  try {
    if (Notification.permission === "default") {
      await Notification.requestPermission();
    }
    if (Notification.permission !== "granted") return;

    const supported = await messagingSupported();
    if (!supported) return;

    messagingRegistration = await navigator.serviceWorker.register("./firebase-messaging-sw.js");
    messaging = getMessaging(app);

    const tokenOptions = { serviceWorkerRegistration: messagingRegistration };
    if (PUSH_VAPID_KEY) tokenOptions.vapidKey = PUSH_VAPID_KEY;

    const token = await getToken(messaging, tokenOptions);
    if (token && uid) {
      await set(ref(db, `${ROOT}/adminTokens/${uid}`), {
        token,
        updatedAt: Date.now()
      });
    }

    onMessage(messaging, (payload) => {
      const body = payload?.notification?.body || payload?.data?.body || "Ada pembaruan GRUP ORDER.";
      toast(body);
      if (soundEnabled) {
        try { ringOrder(); vibrateAlert("new"); } catch {}
      }
    });
  } catch (e) {
    console.warn("Push admin belum aktif:", e);
  }
}

async function driverLogin() {
  try {
    await ensureAuth();

    const name = $("nameInput")?.value.trim();
    const gender = $("driverGender")?.value;
    const pin = $("driverPin")?.value.trim();

    if (!gender) {
      throw new Error("Pilih jenis kelamin driver terlebih dahulu.");
    }
    if (pin !== "1234") {
      throw new Error("PIN peserta salah. Masukkan 1234.");
    }

    const key = await reserveName(name, gender, pin);

    myName = name;
    role = "driver";

    const savedPhoto = localStorage.getItem("go_photo_" + norm(name));
    if (savedPhoto) {
      await update(ref(db, `${ROOT}/drivers/${uid}`), {
        photo: savedPhoto,
        gender,
        updatedAt: Date.now()
      });
    }

    localStorage.setItem("go_nameKey", key);
    localStorage.setItem(
      "go_session",
      JSON.stringify({ role: "driver", name, gender })
    );

    if ($("driverName")) $("driverName").textContent = name;
    if ($("driverNameHero")) $("driverNameHero").textContent = name;

    show("loginCard", false);
    show("driverPanel", true);
    show("adminPanel", false);

    await setupBackgroundNotifications();
    bindDriver();
    toast("Berhasil masuk sebagai driver.");
  } catch (e) {
    toast(e.message || "Gagal masuk.");
  }
}

function setDriverPhoto(src) {
  const img = $("driverPhoto");
  const frame = document.querySelector(".photo-frame");

  if (!img || !frame) return;

  if (src) {
    img.src = src;
    frame.classList.add("has-photo");
  } else {
    img.removeAttribute("src");
    frame.classList.remove("has-photo");
  }
}

async function saveDriverPhoto(file) {
  if (!file || !file.type.startsWith("image/")) {
    return toast("Pilih file foto yang valid.");
  }

  const reader = new FileReader();

  reader.onload = () => {
    const img = new Image();

    img.onload = async () => {
      const max = 420;
      const scale = Math.min(1, max / Math.max(img.width, img.height));

      const c = document.createElement("canvas");
      c.width = Math.round(img.width * scale);
      c.height = Math.round(img.height * scale);

      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);

      const data = c.toDataURL("image/jpeg", 0.72);

      localStorage.setItem("go_photo_" + norm(myName), data);
      setDriverPhoto(data);

      try {
        await update(ref(db, `${ROOT}/drivers/${uid}`), {
          photo: data,
          updatedAt: Date.now()
        });
        toast("Foto driver berhasil disimpan.");
      } catch {
        toast("Foto tersimpan di HP, tetapi gagal disimpan ke server.");
      }
    };

    img.src = reader.result;
  };

  reader.readAsDataURL(file);
}

if ($("driverPhotoInput")) {
  $("driverPhotoInput").onchange = (e) =>
    saveDriverPhoto(e.target.files?.[0]);
}

if ($("soundBtn")) {
  const syncSoundButton = () => {
    $("soundBtn").textContent = soundEnabled ? "◖))) SUARA ON" : "◖) SUARA OFF";
    $("soundBtn").className = soundEnabled ? "sound-toggle on" : "sound-toggle off";
  };
  syncSoundButton();
  $("soundBtn").onclick = () => {
    soundEnabled = !soundEnabled;
    localStorage.setItem("go_sound", soundEnabled ? "on" : "off");
    if (soundEnabled) {
      unlockAudio();
      speakSequence("Suara aktif", 1, "received");
    } else {
      try { window.speechSynthesis?.cancel(); navigator.vibrate?.(0); } catch {}
    }
    syncSoundButton();
  };
}

function bindDriverChat() {
  if (driverChatBound) return;
  driverChatBound = true;

  const chatRef = ref(db, `${ROOT}/driverChat`);

  listeners.push(
    onValue(chatRef, (s) => {
      const data = s.val() || {};

      const items = Object.entries(data)
        .map(([id, m]) => ({ id, ...m }))
        .sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0))
        .slice(-100);

      const box = $("driverChatMessages");
      if (!box) return;

      if (!items.length) {
        box.innerHTML =
          '<div class="chat-empty">Belum ada percakapan. Jadilah yang pertama berkomentar 👋</div>';
        return;
      }

      box.innerHTML = items
        .map((m) => {
          const mine = m.uid === uid;
          const photo = m.photo
            ? `<img src="${esc(m.photo)}" alt="">`
            : "<span>👤</span>";

          return `
            <div class="driver-chat-msg ${mine ? "mine" : ""}">
              <div class="chat-avatar">${photo}</div>
              <div class="chat-bubble">
                <div class="chat-meta">
                  <b>${esc(m.name || "Driver")}</b>
                  <span>${new Date(m.createdAt || Date.now()).toLocaleTimeString(
                    "id-ID",
                    { hour: "2-digit", minute: "2-digit" }
                  )}</span>
                </div>
                <div class="chat-text">${esc(m.text || "")}</div>
              </div>
            </div>`;
        })
        .join("");

      box.scrollTop = box.scrollHeight;
    })
  );

  document.querySelectorAll(".emoji-btn").forEach((btn) => {
    btn.onclick = () => {
      const input = $("driverChatInput");
      if (!input) return;
      input.value += btn.textContent;
      input.focus();
    };
  });

  const send = async () => {
    const input = $("driverChatInput");
    const text = input?.value.trim();

    if (!text) return;

    try {
      const d = (
        await new Promise((resolve) =>
          onValue(
            ref(db, `${ROOT}/drivers/${uid}`),
            resolve,
            { onlyOnce: true }
          )
        )
      ).val() || {};

      await push(chatRef, {
        uid,
        name: d.name || myName || "Driver",
        photo: d.photo || "",
        text: text.slice(0, 1000),
        createdAt: Date.now()
      });

      input.value = "";
    } catch {
      toast("Pesan gagal dikirim.");
    }
  };

  if ($("driverChatSend")) $("driverChatSend").onclick = send;

  if ($("driverChatInput")) {
    $("driverChatInput").onkeydown = (e) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        send();
      }
    };
  }
}

function bindDriver() {
  clearListeners();
  driverChatBound = false;
  bindDriverChat();

  listeners.push(
    onValue(ref(db, `${ROOT}/drivers/${uid}`), (s) => {
      const d = s.val() || {};

      window.__myDriverBusyUntil = d.busyUntil || 0;
      window.__myDriverGender = d.gender || "";

      if ($("driverState")) {
        $("driverState").textContent = d.busy
          ? `SIBUK — ${fmtMs(remainingMs(d))}`
          : d.ready
          ? "SIAP"
          : "TIDAK SIAP";

        $("driverState").className = "pill" + (d.busy ? " busy" : "");
      }

      const ob = $("driverOnlineToggle");
      const pc = document.querySelector(".driver-power-card");
      const ot = $("onlineText");

      if (ob) {
        const on = !!d.online;
        ob.textContent = on ? "🟢 ON" : "🔴 OFF";
        ob.className = on ? "green big" : "red big";
        ob.disabled = !!d.busy && on;
      }

      if (pc) pc.classList.toggle("offline", !d.online);
      if (ot) {
        ot.textContent = d.online
          ? "🟢 ANDA ONLINE"
          : "🔴 ANDA OFFLINE";
      }

      if ($("readyBtn")) {
        $("readyBtn").disabled = !!d.busy || !d.online;
      }

      if ($("notReadyBtn")) {
        $("notReadyBtn").disabled = !!d.busy || !d.online;
      }

      if ($("femaleRequestBtn")) {
        $("femaleRequestBtn").disabled = !!d.busy || !d.online;
      }

      if ($("femaleStatus")) {
        $("femaleStatus").textContent = d.requestFemale
          ? "Request Cewek aktif — admin akan melihatnya."
          : "";
      }

      setDriverPhoto(
        d.photo || localStorage.getItem("go_photo_" + norm(myName))
      );

      if ($("driverGender")) {
        $("driverGender").value =
          d.gender || $("driverGender").value || "";
      }
    })
  );

  let latestOrders = {};
  let latestDrivers = {};

  const renderOnlineRoster = (drivers) => {
    const box = $("onlineDriverRoster");
    if (!box) return;
    const arr = Object.values(drivers || {})
      .filter(d => d && d.online)
      .sort((a,b) => String(a.name||"").localeCompare(String(b.name||"")));
    if ($("onlineDriverCount")) $("onlineDriverCount").textContent = arr.length;
    box.innerHTML = arr.length ? arr.map(d => `
      <div class="online-driver-chip">
        ${d.photo ? `<img src="${esc(d.photo)}" alt="">` : `<span class="avatar">🛵</span>`}
        <div style="min-width:0"><b><span class="online-dot"></span>${esc(d.name||"Driver")}</b></div>
      </div>`).join("") : `<div class="tiny">Belum ada driver yang online.</div>`;
  };

  const refreshDriverViews = () => {
    const mine = Object.values(latestOrders).filter(
      (o) =>
        o &&
        o.driverIds &&
        o.driverIds[uid] &&
        o.status !== "completed" &&
        !o.finishedBy?.[uid]
    );

    if ($("orderCount")) $("orderCount").textContent = mine.length;

    if ($("driverOrders")) {
      $("driverOrders").innerHTML = mine.length
        ? mine.map(orderCard).join("")
        : "<p class='muted'>Belum ada order aktif.</p>";
    }

    renderTeamOrders(latestOrders, latestDrivers);
  };

  listeners.push(
    onValue(ref(db, `${ROOT}/drivers`), (s) => {
      latestDrivers = s.val() || {};
      window.__latestDrivers = latestDrivers;
      renderOnlineRoster(latestDrivers);
      refreshDriverViews();
    })
  );

  listeners.push(
    onValue(ref(db, `${ROOT}/orders`), (s) => {
      latestOrders = s.val() || {};
      window.__latestOrders = latestOrders;
      refreshDriverViews();
    })
  );

  addDriverOpenOrders();
}

function getMyBusyUntil() {
  return window.__myDriverBusyUntil || 0;
}

function orderCard(o) {
  const drivers = Object.values(o.driverNames || {});
  const mine = o.driverIds?.[uid] && !o.finishedBy?.[uid];

  const remaining = Math.max(0, getMyBusyUntil() - Date.now());
  const finishLocked = remaining > 0;
  const action = mine
    ? `<div class="order-actions">
        <button class="green finish-driver-btn" data-finish-button="${esc(o.id)}" ${finishLocked ? "disabled" : ""} onclick="finishDriverOrder('${o.id}')">✅ SUDAH SELESAI</button>
        <button class="red" onclick="cancelDriverOrder('${o.id}')">✖ BATALKAN ORDER</button>
      </div>
      <p class="tiny timer-hint" data-finish-hint="${esc(o.id)}">${finishLocked ? "🔒 Mohon tunggu waktu selesai sampai habis. Setelah 5 menit, tekan SUDAH SELESAI agar bisa mengambil order berikutnya." : "✅ Waktu 5 menit habis. Silakan tekan SUDAH SELESAI untuk mengambil order berikutnya."}</p>`
    : "";

  const timer = mine
    ? `<p class="timerLine">⏱️ Durasi terkunci:
        <b data-countdown="${getMyBusyUntil()}">${fmtMs(remaining)}</b>
      </p>`
    : "";

  const ti = orderTypeInfo(o.orderType || (o.requestFemale ? "female" : "makanan"));

  return `
    <div class="order">
      <div class="between">
        <div>
          <b>${esc(ti.label)}</b>
          <div class="muted">${esc(
            o.mode === "two" ? "Boncengan" : "1 driver"
          )}</div>
        </div>
        <span class="tag ${
          o.requestFemale || o.requestMale ? "pinkTag" : ""
        }">${esc(o.status)}</span>
      </div>
      ${
        o.note
          ? `<div class="order-note-view">${esc(o.note)}</div>`
          : ""
      }
      <p class="muted">Driver: ${
        drivers.map(esc).join(", ") || "Belum diambil"
      }</p>
      ${timer}
      <p class="tiny">Order dibuat ${new Date(
        o.createdAt || Date.now()
      ).toLocaleTimeString("id-ID")}</p>
      ${action}
    </div>`;
}

function teamAssignmentRows(o, drivers) {
  const ids = Object.keys(o.driverIds || {});
  if (!ids.length) return "";

  return ids
    .map((did) => {
      const name =
        o.driverNames?.[did] || drivers[did]?.name || "Driver";
      const assigned = o.assignedAt?.[did] || 0;
      const finished = o.finishedBy?.[did];
      const d = drivers[did] || {};
      const left = d.busy ? remainingMs(d) : 0;

      const state = finished
        ? "✅ SELESAI"
        : d.busy
        ? `🟠 SIBUK — <b data-countdown="${d.busyUntil || 0}">${fmtMs(
            left
          )}</b>`
        : "🟢 SIAP";

      const cls = finished || !d.busy ? "greenTag" : "";

      return `
        <div class="team-driver-row">
          <div>
            <b>👤 ${esc(name)}</b>
            <div class="tiny">🕐 Dapat: ${
              assigned
                ? new Date(assigned).toLocaleTimeString("id-ID", {
                    hour: "2-digit",
                    minute: "2-digit",
                    second: "2-digit"
                  })
                : "-"
            }</div>
          </div>
          <span class="tag ${cls}">${state}</span>
        </div>`;
    })
    .join("");
}

function renderTeamOrders(allOrders, drivers) {
  const arr = Object.values(allOrders || {})
    .filter(
      (o) =>
        o &&
        o.status !== "completed" &&
        Object.keys(o.driverIds || {}).length
    )
    .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

  if ($("teamOrderCount")) $("teamOrderCount").textContent = arr.length;

  if (!$("teamOrders")) return;

  $("teamOrders").innerHTML = arr.length
    ? arr
        .map((o) => {
          const names = Object.values(o.driverNames || {});

          return `
            <div class="order">
              <div class="between">
                <div>
                  <b>📦 ${esc(o.title || "Pesanan")}</b>
                  <div class="muted">${
                    o.mode === "two"
                      ? "🏍️ BONCENGAN"
                      : "🛵 1 DRIVER"
                  }</div>
                </div>
                <span class="tag ${
                  o.requestFemale ? "pinkTag" : ""
                }">${
                  o.requestFemale
                    ? "🚺 REQUEST CEWEK"
                    : esc(o.status)
                }</span>
              </div>
              <div class="tiny" style="margin:8px 0 4px">
                👥 Yang mendapat pesanan:
              </div>
              <div>${teamAssignmentRows(o, drivers)}</div>
            </div>`;
        })
        .join("")
    : "<p class='muted'>Belum ada driver yang mendapat pesanan.</p>";
}

if ($("driverLoginBtn")) $("driverLoginBtn").onclick = driverLogin;

if ($("readyBtn")) {
  $("readyBtn").onclick = async () => {
    const snap = await new Promise((resolve) =>
      onValue(
        ref(db, `${ROOT}/drivers/${uid}`),
        resolve,
        { onlyOnce: true }
      )
    );

    const d = snap.val() || {};

    if (d.busy) {
      return toast(
        "Masih dalam waktu 5 menit. Hanya admin yang bisa membuka driver lebih cepat."
      );
    }

    await update(ref(db, `${ROOT}/drivers/${uid}`), {
      ready: true,
      updatedAt: Date.now()
    });
  };
}

if ($("notReadyBtn")) {
  $("notReadyBtn").onclick = async () => {
    const snap = await new Promise((resolve) =>
      onValue(
        ref(db, `${ROOT}/drivers/${uid}`),
        resolve,
        { onlyOnce: true }
      )
    );

    const d = snap.val() || {};

    if (d.busy) {
      return toast(
        "Driver sedang BUSY. Hanya admin yang bisa membuka lebih cepat."
      );
    }

    await update(ref(db, `${ROOT}/drivers/${uid}`), {
      ready: false,
      updatedAt: Date.now()
    });
  };
}

if ($("femaleRequestBtn")) {
  $("femaleRequestBtn").onclick = async () => {
    await update(ref(db, `${ROOT}/drivers/${uid}`), {
      requestFemale: true,
      updatedAt: Date.now()
    });

    toast("Request Cewek dikirim ke admin.");
  };
}

async function adminLogin() {
  const code = $("adminCode")?.value || "";

  const data = new TextEncoder().encode(code);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hash = [...new Uint8Array(hashBuffer)]
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");

  if (hash !== ADMIN_CODE_HASH) {
    toast("Kode admin salah.");
    return;
  }

  await ensureAuth();

  role = "admin";
  localStorage.setItem(
    "go_session",
    JSON.stringify({ role: "admin" })
  );

  show("loginCard", false);
  show("driverPanel", false);
  show("adminPanel", true);

  await setupAdminBackgroundNotifications();
  bindAdmin();
  toast("Mode admin aktif.");
}

if ($("adminLoginBtn")) $("adminLoginBtn").onclick = adminLogin;

function bindAdmin() {
  clearListeners();

  listeners.push(
    onValue(ref(db, `${ROOT}/drivers`), (s) => {
      const ds = s.val() || {};
      // Admin melihat SEMUA peserta, termasuk nama kembar/double login.
      // Dengan begitu admin bisa memilih akun mana yang harus dibuang.
      // Gunakan key Firebase sebagai ID utama. Ini penting untuk akun lama/stale
      // yang field `uid`-nya kosong atau berbeda dari key record.
      const arr = Object.entries(ds)
        .filter(([, d]) => Boolean(d))
        .map(([dbKey, d]) => ({ ...d, __dbKey: dbKey, uid: d.uid || dbKey }))
        .sort((a, b) =>
          String(a.name || "").localeCompare(String(b.name || ""), "id-ID")
        );

      const ready = arr.filter((d) => d.ready && !d.busy && d.online);
      const busy = arr.filter((d) => d.busy);

      if ($("readyTotal")) $("readyTotal").textContent = ready.length;
      if ($("busyTotal")) $("busyTotal").textContent = busy.length;

      if ($("driverList")) {
        $("driverList").innerHTML = arr.length
          ? arr.map((d) => driverRow(d)).join("")
          : "<p class='muted'>Belum ada driver.</p>";
      }
    })
  );

  listeners.push(
    onValue(ref(db, `${ROOT}/orders`), (s) => {
      const all = s.val() || {};
      lastOrders = all;

      const arr = Object.entries(all)
        .map(([id, o]) => ({ id, ...o }))
        .filter((o) => o.status !== "completed")
        .sort(
          (a, b) => (b.createdAt || 0) - (a.createdAt || 0)
        );

      if ($("openTotal")) $("openTotal").textContent = arr.length;

      const ids = new Set(arr.map((o) => o.id));

      if (lastOpenIds.size > 0) {
        for (const id of ids) {
          if (!lastOpenIds.has(id)) { toast("📣 ADA ORDERAN BARU"); announceNewOrder(); }
        }
      }

      lastOpenIds = ids;

      for (const [id, o] of Object.entries(all)) {
        const previousOrder = adminPreviousOrders[id];
        if (adminOrderSnapshotReady && previousOrder &&
            previousOrder.status !== "completed" && o?.status === "completed") {
          toast("✅ ORDERAN SELESAI");
          announceOrderFinished();
        }

        const currentIds = Object.keys(o?.driverIds || {});
        const previousIds = adminClaimState[id] || [];

        if (
          adminOrderSnapshotReady &&
          currentIds.length > previousIds.length
        ) {
          const added = currentIds.filter(
            (x) => !previousIds.includes(x)
          );

          for (const did of added) {
            const driverName =
              o.driverNames?.[did] || "Driver";
            toast(`🔔 ${driverName} yang ambil order`);
            announceOrderReceived(driverName);
          }
        }

        adminClaimState[id] = currentIds;
      }

      adminPreviousOrders = all;
      adminOrderSnapshotReady = true;

      if ($("adminOrders")) {
        $("adminOrders").innerHTML = arr.length
          ? arr.map((o) => adminOrderCard(o)).join("")
          : "<p class='muted'>Tidak ada pesanan aktif.</p>";
      }
    })
  );
}
function remainingMs(d) {
  return Math.max(0, (d?.busyUntil || 0) - Date.now());
}

function fmtMs(ms) {
  const sec = Math.ceil(Math.max(0, ms) / 1000);
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(
    2,
    "0"
  )}`;
}

function fmtDuration(ms) {
  const sec = Math.floor(Math.max(0, ms) / 1000);
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  return h > 0
    ? `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`
    : `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

function driverRow(d) {
  const left = remainingMs(d);

  const status = d.busy
    ? `BUSY — ${fmtMs(left)}`
    : !d.online
    ? "OFFLINE"
    : d.ready
    ? "READY"
    : "TIDAK READY";

  const active = Object.values(lastOrders || {}).find(
    (o) =>
      o?.driverIds?.[d.uid] &&
      o.status !== "completed"
  );

  const orderText = active
    ? `📦 ${esc(active.title || "Pesan")}`
    : "";
  const timerHtml = d.busy
    ? `<div class="admin-timer">⏱️ <b data-countdown="${d.busyUntil || 0}">${fmtMs(left)}</b></div>`
    : "";

  return `
    <div class="driver">
      <div class="between">
        <div class="admin-driver-main">
          ${
            d.photo
              ? `<img class="admin-driver-photo" src="${esc(
                  d.photo
                )}" alt="">`
              : `<div class="admin-driver-photo placeholder">🛵</div>`
          }
          <div>
            <span class="driverName">${esc(d.name)}</span>
            <div class="tiny">${
              d.gender === "female"
                ? "👩 Cewek"
                : d.gender === "male"
                ? "👨 Cowok"
                : "Jenis kelamin belum diatur"
            }</div>
          </div>
        </div>

        <span class="tag ${
          d.online && d.ready && !d.busy
            ? "greenTag"
            : !d.online
            ? "redTag"
            : ""
        }">${status}</span>
      </div>

      ${timerHtml}
      ${
        orderText
          ? `<div class="tiny" style="margin-top:7px">${orderText}</div>`
          : ""
      }

      ${
        d.requestFemale
          ? `<div class="tag pinkTag" style="display:inline-block;margin-top:8px">
              🚺 REQUEST CEWEK
            </div>`
          : ""
      }

      ${
        d.busy
          ? `<div class="order-actions">
              <button class="blue" onclick="adminReleaseDriver('${d.uid}')">
                🔓 BUKA DRIVER SEKARANG
              </button>
            </div>`
          : ""
      }

      <div class="order-actions admin-driver-actions">
        <button class="red" onclick="adminDeleteDriver('${d.uid}')">
          🗑️ HAPUS PESERTA
        </button>
      </div>
    </div>`;
}

function adminOrderCard(o) {
  const names = Object.values(o.driverNames || {});
  const finished = Object.values(o.finishedBy || {})
    .map((x) => x?.name || "")
    .filter(Boolean);

  const driverButtons = Object.keys(o.driverIds || {})
    .map(
      (did) =>
        `<button class="blue" onclick="adminReleaseDriver('${did}')">
          🔓 BUKA ${esc(o.driverNames?.[did] || "DRIVER")}
        </button>`
    )
    .join("");

  const ti = orderTypeInfo(
    o.orderType || (o.requestFemale ? "female" : "makanan")
  );

  return `
    <div class="order">
      <div class="between">
        <div>
          <b>${esc(ti.label)}</b>
          <div class="muted">${
            o.mode === "two"
              ? "🏍️ BONCENGAN"
              : "🛵 1 DRIVER"
          }</div>
        </div>
        <span class="tag ${
          o.requestFemale || o.requestMale
            ? "pinkTag"
            : ""
        }">${esc(o.status)}</span>
      </div>

      ${
        o.note
          ? `<div class="order-note-view">${esc(o.note)}</div>`
          : `<p class="tiny">Tidak ada keterangan.</p>`
      }

      <p class="muted">
        ${names.length ? names.map(esc).join(", ") : "Belum diambil"}
      </p>

      <p class="timerLine order-duration-line">
        ⏱️ Durasi order: <b data-elapsed="${o.createdAt || Date.now()}">${fmtDuration(Date.now() - (o.createdAt || Date.now()))}</b>
        <span class="tiny">• dibuat ${new Date(o.createdAt || Date.now()).toLocaleTimeString("id-ID", {hour:"2-digit", minute:"2-digit", second:"2-digit"})}</span>
      </p>

      ${
        finished.length
          ? `<p class="tiny">✅ Selesai: ${finished
              .map(esc)
              .join(", ")}</p>`
          : ""
      }

      <div class="order-actions">
        ${driverButtons}
        <button class="red" onclick="adminCancelCustomerOrder('${o.id}')">
          ❌ CUSTOMER BATAL
        </button>
        <button class="red" onclick="completeOrder('${o.id}')">
          SELESAIKAN ORDER
        </button>
      </div>
    </div>`;
}

function notify(msg, loud = true) {
  toast(msg);
  if (loud) ringOrder();
  if ("Notification" in window && Notification.permission === "granted") {
    try { new Notification("🚗 GRUP ORDER", { body: msg, tag: "grup-order" }); } catch {}
  }
}

if ($("newOrderBtn")) {
  $("newOrderBtn").onclick = async () => {
    const id = push(ref(db, `${ROOT}/orders`)).key;
    const type = selectedOrderType;
    const note = $("orderNote")?.value.trim() || "";
    const requestFemale = type === "female";
    const requestMale = type === "male";
    const ti = orderTypeInfo(type);

    await set(ref(db, `${ROOT}/orders/${id}`), {
      id,
      title: ti.label,
      status: "open",
      mode: selectedMode,
      orderType: type,
      requestFemale,
      requestMale,
      note,
      driverIds: {},
      driverNames: {},
      assignedAt: {},
      createdAt: Date.now(),
      createdBy: "admin"
    });

    if ($("orderNote")) $("orderNote").value = "";

    toast(`${ti.icon} ${ti.label} — pesanan baru dibuat.`);
  };
}

document.querySelectorAll(".order-type-option").forEach((btn) => {
  btn.onclick = () => {
    selectedOrderType = btn.dataset.type || "makanan";

    document
      .querySelectorAll(".order-type-option")
      .forEach((x) =>
        x.classList.toggle("selected", x === btn)
      );
  };
});

if ($("twoDriverBtn")) {
  $("twoDriverBtn").onclick = () => {
    selectedMode = selectedMode === "two" ? "one" : "two";
    $("twoDriverBtn").className = selectedMode === "two" ? "green big" : "dark big";
    $("twoDriverBtn").title = selectedMode === "two"
      ? "Boncengan aktif (2 driver). Tekan lagi untuk kembali ke 1 driver."
      : "Mode normal 1 driver. Tekan untuk memilih Boncengan.";
  };
}

async function getOrderOnce(id) {
  const snap = await new Promise((resolve) =>
    onValue(
      ref(db, `${ROOT}/orders/${id}`),
      resolve,
      { onlyOnce: true }
    )
  );

  return snap.val();
}

window.cancelDriverOrder = async (id) => {
  const os = ref(db, `${ROOT}/orders/${id}`);

  const tx = await runTransaction(os, (current) => {
    if (
      !current ||
      current.status === "completed" ||
      !current.driverIds?.[uid] ||
      current.finishedBy?.[uid]
    ) {
      return;
    }

    const ids = { ...(current.driverIds || {}) };
    const names = { ...(current.driverNames || {}) };
    const assignedAt = { ...(current.assignedAt || {}) };

    delete ids[uid];
    delete names[uid];
    delete assignedAt[uid];

    current.driverIds = ids;
    current.driverNames = names;
    current.assignedAt = assignedAt;

    const need = current.mode === "two" ? 2 : 1;
    if (Object.keys(ids).length < need) {
      current.status = "open";
    }

    return current;
  });

  if (!tx.committed) {
    return toast("Pesanan tidak bisa dibatalkan.");
  }

  await update(ref(db, `${ROOT}/drivers/${uid}`), {
    busy: false, ready: true, busyUntil: 0, requestFemale: false, updatedAt: Date.now()
  });
  toast("Pesanan dibatalkan. Driver langsung READY dan bisa ambil order berikutnya.");
};

window.finishDriverOrder = async (id) => {
  const driverSnap = await new Promise((resolve) =>
    onValue(ref(db, `${ROOT}/drivers/${uid}`), resolve, { onlyOnce: true })
  );
  const driver = driverSnap.val() || {};
  const remaining = Math.max(0, (driver.busyUntil || 0) - Date.now());

  if (driver.busy && remaining > 0) {
    return toast("⏳ Mohon tunggu waktu selesai sampai habis.");
  }

  const os = ref(db, `${ROOT}/orders/${id}`);

  const tx = await runTransaction(os, (current) => {
    if (
      !current ||
      current.status === "completed" ||
      !current.driverIds?.[uid] ||
      current.finishedBy?.[uid]
    ) {
      return;
    }

    current.finishedBy = current.finishedBy || {};
    current.finishedBy[uid] = {
      name: myName,
      finishedAt: Date.now()
    };

    const need = current.mode === "two" ? 2 : 1;
    const assigned = Object.keys(current.driverIds || {}).length;
    const finished = Object.keys(current.finishedBy || {}).length;

    if (finished >= assigned && assigned >= need) {
      current.status = "completed";
    }

    return current;
  });

  if (!tx.committed) {
    return toast("Pesanan tidak bisa ditandai selesai.");
  }

  await update(ref(db, `${ROOT}/drivers/${uid}`), {
    busy: false, ready: true, busyUntil: 0, requestFemale: false, updatedAt: Date.now()
  });
  toast("✅ Pesanan selesai. Anda sekarang READY dan bisa ambil order berikutnya.");
};

window.adminReleaseDriver = async (driverId) => {
  if (role !== "admin") {
    return toast("Hanya admin yang bisa membuka driver lebih cepat.");
  }

  const snap = await new Promise((resolve) =>
    onValue(
      ref(db, `${ROOT}/drivers/${driverId}`),
      resolve,
      { onlyOnce: true }
    )
  );

  const d = snap.val();

  if (!d) return toast("Driver tidak ditemukan.");

  await update(ref(db, `${ROOT}/drivers/${driverId}`), {
    busy: false,
    ready: true,
    busyUntil: 0,
    requestFemale: false,
    updatedAt: Date.now(),
    releasedByAdminAt: Date.now()
  });

  toast(
    `${d.name || "Driver"} sekarang READY dan boleh ambil pesanan baru.`
  );
};

window.adminClearAllTimers = async () => {
  if (role !== "admin") return toast("Hanya admin yang bisa menghapus semua timer.");

  const snap = await new Promise((resolve) =>
    onValue(ref(db, `${ROOT}/drivers`), resolve, { onlyOnce: true })
  );
  const drivers = snap.val() || {};
  let count = 0;

  for (const [did, d] of Object.entries(drivers)) {
    if (d?.busy || d?.busyUntil) {
      await update(ref(db, `${ROOT}/drivers/${did}`), {
        busy: false,
        ready: !!d.online,
        busyUntil: 0,
        requestFemale: false,
        updatedAt: Date.now(),
        releasedByAdminAt: Date.now()
      });
      count++;
    }
  }

  toast(count
    ? `🚨 ${count} timer driver dihapus. Driver yang ONLINE kembali READY.`
    : "Tidak ada timer aktif.");
};

window.adminDeleteDriver = async (driverId) => {
  if (role !== "admin") {
    return toast("Hanya admin yang bisa menghapus driver.");
  }

  // `driverId` boleh berupa key Firebase lama maupun uid. Cari record dari keduanya.
  const candidateIds = [...new Set([String(driverId)])];
  let d = null;
  let dbKey = String(driverId);

  for (const candidate of candidateIds) {
    const snap = await new Promise((resolve) =>
      onValue(ref(db, `${ROOT}/drivers/${candidate}`), resolve, { onlyOnce: true })
    );
    if (snap.exists()) {
      d = snap.val();
      dbKey = candidate;
      break;
    }
  }

  if (!d) return toast("Peserta tidak ditemukan atau data sudah terhapus.");

  const uidAlias = String(d.uid || dbKey);
  const idsToRemove = new Set([dbKey, uidAlias]);

  if (!confirm(`Hapus peserta "${d.name || "Driver"}" dari daftar?\n\nAdmin dapat menghapus peserta walaupun ONLINE, READY, OFFLINE, atau sedang BUSY.`)) {
    return;
  }

  try {
    const nameKey = norm(d.name || "");

    // Lepaskan semua order yang masih mengacu ke key/uid akun ini.
    const ordersSnap = await new Promise((resolve) =>
      onValue(ref(db, `${ROOT}/orders`), resolve, { onlyOnce: true })
    );
    const orders = ordersSnap.val() || {};

    for (const [oid, o] of Object.entries(orders)) {
      if (!o || o.status === "completed" || o.status === "cancelled") continue;
      const matched = [...idsToRemove].some((id) => !!o.driverIds?.[id]);
      if (!matched) continue;

      await runTransaction(ref(db, `${ROOT}/orders/${oid}`), (current) => {
        if (!current) return current;
        const ids = { ...(current.driverIds || {}) };
        const names = { ...(current.driverNames || {}) };
        const assignedAt = { ...(current.assignedAt || {}) };
        const finishedBy = { ...(current.finishedBy || {}) };
        for (const id of idsToRemove) {
          delete ids[id];
          delete names[id];
          delete assignedAt[id];
          delete finishedBy[id];
        }
        current.driverIds = ids;
        current.driverNames = names;
        current.assignedAt = assignedAt;
        current.finishedBy = finishedBy;
        const need = current.mode === "two" ? 2 : 1;
        if (Object.keys(ids).length < need && current.status !== "completed") current.status = "open";
        return current;
      });
    }

    // Hapus record peserta berdasarkan key Firebase yang sebenarnya.
    await remove(ref(db, `${ROOT}/drivers/${dbKey}`));

    // Bersihkan index nama hanya jika index tersebut memang menunjuk ke akun yang dihapus.
    if (nameKey) {
      const nr = ref(db, `${ROOT}/nameIndex/${encodeURIComponent(nameKey)}`);
      const ns = await new Promise((resolve) => onValue(nr, resolve, { onlyOnce: true }));
      const indexed = String(ns.val() || "");
      if (idsToRemove.has(indexed)) await remove(nr);
    }

    // Bersihkan token notifikasi yang masih tersimpan untuk akun lama.
    await remove(ref(db, `${ROOT}/adminTokens/${dbKey}`)).catch(() => {});
    await remove(ref(db, `${ROOT}/fcmTokens/${dbKey}`)).catch(() => {});

    toast(`${d.name || "Driver"} berhasil dihapus.`);
  } catch (err) {
    console.error("adminDeleteDriver", err);
    toast(`Gagal menghapus peserta: ${err?.message || "izin Firebase atau koneksi bermasalah"}`);
  }
};

window.adminCancelCustomerOrder = async (id) => {
  if (role !== "admin") return toast("Hanya admin yang bisa membatalkan order.");
  const o = await getOrderOnce(id);
  if (!o) return;
  if (!confirm("Batalkan order customer ini dan bebaskan semua driver?")) return;

  await update(ref(db, `${ROOT}/orders/${id}`), {
    status: "cancelled", cancelledAt: Date.now(), cancelledBy: "customer/admin"
  });

  for (const did of Object.keys(o.driverIds || {})) {
    await update(ref(db, `${ROOT}/drivers/${did}`), {
      busy: false, ready: true, busyUntil: 0, requestFemale: false, updatedAt: Date.now()
    });
  }
  toast("Order dibatalkan. Semua driver terkait langsung READY.");
};

window.completeOrder = async (id) => {
  const o = await getOrderOnce(id);
  if (!o) return;

  await update(ref(db, `${ROOT}/orders/${id}`), {
    status: "completed",
    completedAt: Date.now()
  });

  for (const did of Object.keys(o.driverIds || {})) {
    await update(ref(db, `${ROOT}/drivers/${did}`), {
      busy: false,
      ready: true,
      busyUntil: 0,
      requestFemale: false,
      updatedAt: Date.now()
    });
  }

  toast("Pesanan selesai. Driver dibuka kembali.");
};

if ($("completeAllBtn")) {
  $("completeAllBtn").onclick = async () => {
    const snap = await new Promise((resolve) =>
      onValue(
        ref(db, `${ROOT}/orders`),
        resolve,
        { onlyOnce: true }
      )
    );

    const all = snap.val() || {};

    for (const [id, o] of Object.entries(all)) {
      if (o?.status !== "completed") {
        await window.completeOrder(id);
      }
    }
  };
}

if ($("clearAllTimersBtn")) {
  $("clearAllTimersBtn").onclick = async () => {
    if (!confirm("Hapus semua timer driver sekarang? Semua driver ONLINE akan langsung READY dan dapat mengambil order baru.")) return;
    await window.adminClearAllTimers();
  };
}

window.claimOrder = async (id) => {
  const os = ref(db, `${ROOT}/orders/${id}`);

  const snap = await new Promise((resolve) =>
    onValue(os, resolve, { onlyOnce: true })
  );

  const o = snap.val();

  if (!o || o.status !== "open") {
    return toast("Pesanan sudah diambil.");
  }

  const ds = await new Promise((resolve) =>
    onValue(
      ref(db, `${ROOT}/drivers/${uid}`),
      resolve,
      { onlyOnce: true }
    )
  );

  const d = ds.val();

  if (d?.busy && d.busyUntil && d.busyUntil <= Date.now()) {
    return toast("⏳ Waktu 5 menit sudah habis. Mohon tekan SUDAH SELESAI terlebih dahulu.");
  }

  if (!d?.ready || d.busy) {
    return toast(
      "⏳ Anda masih dalam waktu 5 menit. Mohon tunggu sampai timer habis, lalu tekan SUDAH SELESAI."
    );
  }

  if (!d.online) {
    return toast("Anda sedang OFFLINE. Aktifkan status ONLINE terlebih dahulu.");
  }

  const need = o.mode === "two" ? 2 : 1;

  const currentIds = o.driverIds || {};

  if (Object.keys(currentIds).length >= need) {
    return toast("Slot driver sudah penuh.");
  }

  const type = o.orderType || (o.requestFemale ? "female" : "makanan");

  if (type === "female" && d.gender !== "female") {
    return toast("Pesanan ini khusus driver perempuan.");
  }

  if (type === "male" && d.gender !== "male") {
    return toast("Pesanan ini khusus driver laki-laki.");
  }

  const tx = await runTransaction(os, (current) => {
    if (!current || current.status !== "open") return;

    const ids = { ...(current.driverIds || {}) };

    if (ids[uid]) return;
    if (Object.keys(ids).length >= need) return;

    ids[uid] = true;
    current.driverIds = ids;

    const names = { ...(current.driverNames || {}) };
    names[uid] = myName;
    current.driverNames = names;

    const assignedAt = { ...(current.assignedAt || {}) };
    assignedAt[uid] = Date.now();
    current.assignedAt = assignedAt;

    if (Object.keys(ids).length === need) {
      current.status = "claimed";
    }

    return current;
  });

  if (!tx.committed) {
    return toast("Gagal mengambil pesanan.");
  }

  await update(ref(db, `${ROOT}/drivers/${uid}`), {
    busy: true,
    ready: false,
    busyUntil: Date.now() + BUSY_MS,
    updatedAt: Date.now()
  });

  toast("🔔 ORDERAN BARU DITERIMA.");
};

function addDriverOpenOrders() {
  let previousOpenIds = new Set();
  let previousOrders = {};
  let eventSnapshotReady = false;

  listeners.push(
    onValue(ref(db, `${ROOT}/orders`), (s) => {
      const all = s.val() || {};
      window.__latestOrders = all;

      const open = Object.values(all).filter(o => o?.status === "open");
      const currentOpenIds = new Set(open.map(o => o.id).filter(Boolean));

      if (eventSnapshotReady) {
        // 1) Order baru: suara lucu 2x + getar
        const seenNewIds = new Set();
        for (const o of open) {
          if (o.id && !previousOpenIds.has(o.id) && orderAllowedForDriver(o)) {
            seenNewIds.add(o.id);
            toast(o.requestFemale
              ? "🚺 ADA ORDERAN BARU — REQUEST CEWEK!"
              : "📣 ADA ORDERAN BARU!");
            announceNewOrder(o.requestFemale ? "request cewek" : "");
          }
        }
        // Kalau order dibuat dan langsung direbut sebelum snapshot OPEN sempat tampil,
        // tetap beri tahu driver yang memang memenuhi syarat.
        for (const [id, o] of Object.entries(all)) {
          if (!previousOrders[id] && !seenNewIds.has(id) && orderAllowedForDriver(o)) {
            toast("📣 ADA ORDERAN BARU!");
            announceNewOrder();
          }
        }

        // 2) Driver ini berhasil mengambil order: sebut nama driver 1x + getar
        for (const [id, o] of Object.entries(all)) {
          const old = previousOrders[id];
          const oldIds = Object.keys(old?.driverIds || {});
          const newIds = Object.keys(o?.driverIds || {});
          const newlyTaken = newIds.filter(did => !oldIds.includes(did));
          for (const did of newlyTaken) {
            const takenBy = o.driverNames?.[did] || "Driver";
            announceOrderReceived(takenBy);
          }
          const nowMine = !!o?.driverIds?.[uid];
          const oldMine = !!old?.driverIds?.[uid];

          // 3) Driver menekan SELESAI: suara lucu 2x + getar
          const oldFinished = !!old?.finishedBy?.[uid];
          const nowFinished = !!o?.finishedBy?.[uid];
          if (nowFinished && !oldFinished) announceOrderFinished();

          // 4) Admin/customer membatalkan atau menyelesaikan order
          if (old && old.status !== "completed" && old.status !== "cancelled" &&
              (o?.status === "completed" || o?.status === "cancelled") &&
              (nowMine || oldMine) && !nowFinished) {
            announceOrderFinished();
          }
        }
      }

      previousOpenIds = currentOpenIds;
      previousOrders = all;
      eventSnapshotReady = true;

      const box = $("driverOrders");
      if (!box) return;

      const mine = Object.values(all).filter(
        (o) => o && o.driverIds && o.driverIds[uid] && o.status !== "completed" && o.status !== "cancelled" && !o.finishedBy?.[uid]
      );

      let html = mine.length ? mine.map(orderCard).join("") : "";
      const myGender = window.__myDriverGender || "";

      for (const o of open) {
        const count = Object.keys(o.driverIds || {}).length;
        const need = o.mode === "two" ? 2 : 1;
        const type = o.orderType || (o.requestFemale ? "female" : "makanan");
        const allowed = type === "female" ? myGender === "female" : type === "male" ? myGender === "male" : true;

        if (!o.driverIds?.[uid] && count < need && allowed) {
          const ti = orderTypeInfo(type);
          html += `
            <div class="order new-order-card">
              <div class="between">
                <div>
                  <b>${esc(ti.label)}</b>
                  <div class="muted">${o.mode === "two" ? "Boncengan" : "1 driver"}</div>
                </div>
                <span class="tag ${o.requestFemale || o.requestMale ? "pinkTag" : ""}">PESANAN BARU</span>
              </div>
              ${o.note ? `<div class="order-note-view">${esc(o.note)}</div>` : ""}
              <p class="muted">Slot: ${count}/${need}</p>
              <button class="blue" onclick="claimOrder('${o.id}')">🔔 GABUNGKAN PESANAN</button>
            </div>`;
        }
      }

      box.innerHTML = html || "<p class='muted'>Belum ada pesanan.</p>";
      renderTeamOrders(all, window.__latestDrivers || {});
    })
  );
}

async function setDriverOnline(isOnline) {
  if (role !== "driver" || !uid) return;

  try {
    const snap = await new Promise((resolve) =>
      onValue(
        ref(db, `${ROOT}/drivers/${uid}`),
        resolve,
        { onlyOnce: true }
      )
    );

    const d = snap.val();

    if (!d) {
      return toast("Data driver tidak ditemukan.");
    }

    if (!isOnline && d.busy) {
      return toast(
        "⏳ Anda masih BUSY. Tunggu timer 5 menit atau minta Admin membuka."
      );
    }

    await update(ref(db, `${ROOT}/drivers/${uid}`), {
      online: isOnline,
      manualOff: !isOnline,
      ready: isOnline ? true : false,
      requestFemale: isOnline ? d.requestFemale || false : false,
      updatedAt: Date.now()
    });

    const btn = $("driverOnlineToggle");
    const card = document.querySelector(".driver-power-card");
    const txt = $("onlineText");

    if (btn) {
      btn.textContent = isOnline ? "🟢 ON" : "🔴 OFF";
      btn.className = isOnline ? "green big" : "red big";
    }

    if (card) card.classList.toggle("offline", !isOnline);

    if (txt) {
      txt.textContent = isOnline
        ? "🟢 ANDA ONLINE"
        : "🔴 ANDA OFFLINE";
    }

    toast(
      isOnline
        ? "Anda ONLINE. Admin akan melihat status ONLINE."
        : "Anda OFFLINE. Nama tetap tersimpan."
    );
  } catch {
    toast("Gagal mengubah status ON/OFF.");
  }
}

if ($("driverOnlineToggle")) {
  $("driverOnlineToggle").onclick = async () => {
    const isCurrentlyOn =
      $("driverOnlineToggle").textContent.includes("ON") &&
      !$("driverOnlineToggle").textContent.includes("OFF");

    await setDriverOnline(!isCurrentlyOn);
  };
}

if ($("logoutDriver")) {
  $("logoutDriver").onclick = async () => {
    localStorage.removeItem("go_session");
    sessionStorage.removeItem("go_session");

    try {
      await update(ref(db, `${ROOT}/drivers/${uid}`), {
        online: false,
        updatedAt: Date.now()
      });
    } catch {}

    // Pertahankan sesi Auth anonim agar PIN 1234 + nama yang sama dapat masuk
    // kembali tanpa membuat peserta kedua. Admin tetap dapat menghapus akun.
    role = null;
    show("driverPanel", false);
    show("loginCard", true);
  };
}

if ($("logoutAdmin")) {
  $("logoutAdmin").onclick = async () => {
    localStorage.removeItem("go_session");
    sessionStorage.removeItem("go_session");

    await signOut(auth);

    role = null;
    show("adminPanel", false);
    show("loginCard", true);
  };
}

window.addEventListener("load", () => {
  $("nameInput")?.focus();
});

setInterval(async () => {
  document.querySelectorAll("[data-countdown]").forEach((el) => {
    const until = Number(el.dataset.countdown || 0);
    el.textContent = fmtMs(
      Math.max(0, until - Date.now())
    );
  });

  document.querySelectorAll("[data-elapsed]").forEach((el) => {
    const started = Number(el.dataset.elapsed || 0);
    el.textContent = fmtDuration(Date.now() - started);
  });

  document.querySelectorAll("[data-finish-button]").forEach((btn) => {
    const until = getMyBusyUntil();
    const locked = until > Date.now();
    btn.disabled = locked;
  });

  if (uid && role === "driver") {
    try {
      const snap = await new Promise((resolve) =>
        onValue(
          ref(db, `${ROOT}/drivers/${uid}`),
          resolve,
          { onlyOnce: true }
        )
      );

      const d = snap.val();

      if (d?.busy && d.busyUntil && d.busyUntil <= Date.now()) {
        document.querySelectorAll("[data-finish-button]").forEach((btn) => {
          btn.disabled = false;
        });
        document.querySelectorAll("[data-finish-hint]").forEach((el) => {
          el.textContent = "✅ Waktu 5 menit habis. Silakan tekan SUDAH SELESAI untuk mengambil order berikutnya.";
        });
      }
    } catch {}
  }
}, 1000);

function clearListeners() {
  listeners.forEach((unsub) => {
    try {
      unsub();
    } catch {}
  });

  listeners = [];
  lastOpenIds = new Set();
}
